﻿namespace xianquan2
{
    partial class xianquan
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape35 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape34 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape33 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape32 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape31 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape30 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape29 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape28 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape27 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape26 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape25 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape24 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape23 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape22 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape21 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape18 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape17 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape16 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape15 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape14 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape13 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape12 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape11 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape10 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape9 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.ovalShape2 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ovalShape1 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.lineShape8 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape7 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape6 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape5 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape4 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape20 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape19 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape35,
            this.lineShape34,
            this.lineShape33,
            this.lineShape32,
            this.lineShape31,
            this.lineShape30,
            this.lineShape29,
            this.lineShape28,
            this.lineShape27,
            this.lineShape26,
            this.lineShape25,
            this.lineShape24,
            this.lineShape23,
            this.lineShape22,
            this.lineShape21,
            this.lineShape18,
            this.lineShape17,
            this.lineShape16,
            this.lineShape15,
            this.lineShape14,
            this.lineShape13,
            this.lineShape12,
            this.lineShape11,
            this.lineShape10,
            this.lineShape9,
            this.ovalShape2,
            this.ovalShape1,
            this.lineShape8,
            this.lineShape7,
            this.lineShape6,
            this.lineShape5,
            this.lineShape4,
            this.lineShape3,
            this.lineShape2,
            this.lineShape1,
            this.lineShape20,
            this.lineShape19});
            this.shapeContainer1.Size = new System.Drawing.Size(221, 131);
            this.shapeContainer1.TabIndex = 0;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape35
            // 
            this.lineShape35.Name = "lineShape35";
            this.lineShape35.X1 = 128;
            this.lineShape35.X2 = 117;
            this.lineShape35.Y1 = 27;
            this.lineShape35.Y2 = 29;
            // 
            // lineShape34
            // 
            this.lineShape34.Name = "lineShape34";
            this.lineShape34.X1 = 129;
            this.lineShape34.X2 = 117;
            this.lineShape34.Y1 = 22;
            this.lineShape34.Y2 = 25;
            // 
            // lineShape33
            // 
            this.lineShape33.Name = "lineShape33";
            this.lineShape33.X1 = 129;
            this.lineShape33.X2 = 117;
            this.lineShape33.Y1 = 17;
            this.lineShape33.Y2 = 21;
            // 
            // lineShape32
            // 
            this.lineShape32.Name = "lineShape32";
            this.lineShape32.X1 = 153;
            this.lineShape32.X2 = 159;
            this.lineShape32.Y1 = 10;
            this.lineShape32.Y2 = 7;
            // 
            // lineShape31
            // 
            this.lineShape31.Name = "lineShape31";
            this.lineShape31.X1 = 154;
            this.lineShape31.X2 = 160;
            this.lineShape31.Y1 = 11;
            this.lineShape31.Y2 = 14;
            // 
            // lineShape30
            // 
            this.lineShape30.Name = "lineShape30";
            this.lineShape30.X1 = 129;
            this.lineShape30.X2 = 152;
            this.lineShape30.Y1 = 11;
            this.lineShape30.Y2 = 11;
            // 
            // lineShape29
            // 
            this.lineShape29.Name = "lineShape29";
            this.lineShape29.X1 = 94;
            this.lineShape29.X2 = 100;
            this.lineShape29.Y1 = 10;
            this.lineShape29.Y2 = 5;
            // 
            // lineShape28
            // 
            this.lineShape28.Name = "lineShape28";
            this.lineShape28.X1 = 101;
            this.lineShape28.X2 = 94;
            this.lineShape28.Y1 = 13;
            this.lineShape28.Y2 = 9;
            // 
            // lineShape27
            // 
            this.lineShape27.Name = "lineShape27";
            this.lineShape27.X1 = 115;
            this.lineShape27.X2 = 95;
            this.lineShape27.Y1 = 10;
            this.lineShape27.Y2 = 10;
            // 
            // lineShape26
            // 
            this.lineShape26.Name = "lineShape26";
            this.lineShape26.X1 = 110;
            this.lineShape26.X2 = 134;
            this.lineShape26.Y1 = 16;
            this.lineShape26.Y2 = 16;
            // 
            // lineShape25
            // 
            this.lineShape25.Name = "lineShape25";
            this.lineShape25.X1 = 128;
            this.lineShape25.X2 = 128;
            this.lineShape25.Y1 = 31;
            this.lineShape25.Y2 = 11;
            // 
            // lineShape24
            // 
            this.lineShape24.Name = "lineShape24";
            this.lineShape24.X1 = 116;
            this.lineShape24.X2 = 116;
            this.lineShape24.Y1 = 31;
            this.lineShape24.Y2 = 10;
            // 
            // lineShape23
            // 
            this.lineShape23.Name = "lineShape23";
            this.lineShape23.X1 = 110;
            this.lineShape23.X2 = 136;
            this.lineShape23.Y1 = 31;
            this.lineShape23.Y2 = 31;
            // 
            // lineShape22
            // 
            this.lineShape22.BorderColor = System.Drawing.Color.Black;
            this.lineShape22.Name = "lineShape22";
            this.lineShape22.X1 = 58;
            this.lineShape22.X2 = 84;
            this.lineShape22.Y1 = 90;
            this.lineShape22.Y2 = 90;
            // 
            // lineShape21
            // 
            this.lineShape21.Name = "lineShape21";
            this.lineShape21.X1 = 72;
            this.lineShape21.X2 = 72;
            this.lineShape21.Y1 = 74;
            this.lineShape21.Y2 = 89;
            // 
            // lineShape18
            // 
            this.lineShape18.Name = "lineShape18";
            this.lineShape18.X1 = 149;
            this.lineShape18.X2 = 153;
            this.lineShape18.Y1 = 48;
            this.lineShape18.Y2 = 52;
            // 
            // lineShape17
            // 
            this.lineShape17.Name = "lineShape17";
            this.lineShape17.X1 = 150;
            this.lineShape17.X2 = 153;
            this.lineShape17.Y1 = 46;
            this.lineShape17.Y2 = 44;
            // 
            // lineShape16
            // 
            this.lineShape16.Name = "lineShape16";
            this.lineShape16.X1 = 135;
            this.lineShape16.X2 = 149;
            this.lineShape16.Y1 = 47;
            this.lineShape16.Y2 = 47;
            // 
            // lineShape15
            // 
            this.lineShape15.Name = "lineShape15";
            this.lineShape15.X1 = 106;
            this.lineShape15.X2 = 106;
            this.lineShape15.Y1 = 61;
            this.lineShape15.Y2 = 54;
            // 
            // lineShape14
            // 
            this.lineShape14.Name = "lineShape14";
            this.lineShape14.X1 = 106;
            this.lineShape14.X2 = 106;
            this.lineShape14.Y1 = 35;
            this.lineShape14.Y2 = 41;
            // 
            // lineShape13
            // 
            this.lineShape13.BorderColor = System.Drawing.Color.Black;
            this.lineShape13.Name = "lineShape13";
            this.lineShape13.X1 = 86;
            this.lineShape13.X2 = 106;
            this.lineShape13.Y1 = 61;
            this.lineShape13.Y2 = 61;
            // 
            // lineShape12
            // 
            this.lineShape12.Name = "lineShape12";
            this.lineShape12.X1 = 85;
            this.lineShape12.X2 = 105;
            this.lineShape12.Y1 = 35;
            this.lineShape12.Y2 = 35;
            // 
            // lineShape11
            // 
            this.lineShape11.Name = "lineShape11";
            this.lineShape11.X1 = 15;
            this.lineShape11.X2 = 22;
            this.lineShape11.Y1 = 48;
            this.lineShape11.Y2 = 51;
            // 
            // lineShape10
            // 
            this.lineShape10.Name = "lineShape10";
            this.lineShape10.X1 = 21;
            this.lineShape10.X2 = 15;
            this.lineShape10.Y1 = 44;
            this.lineShape10.Y2 = 46;
            // 
            // lineShape9
            // 
            this.lineShape9.Name = "lineShape9";
            this.lineShape9.X1 = 60;
            this.lineShape9.X2 = 84;
            this.lineShape9.Y1 = 73;
            this.lineShape9.Y2 = 73;
            // 
            // ovalShape2
            // 
            this.ovalShape2.BackColor = System.Drawing.Color.Red;
            this.ovalShape2.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.ovalShape2.BorderColor = System.Drawing.Color.Black;
            this.ovalShape2.FillColor = System.Drawing.Color.WhiteSmoke;
            this.ovalShape2.FillGradientColor = System.Drawing.Color.Black;
            this.ovalShape2.Location = new System.Drawing.Point(65, 53);
            this.ovalShape2.Name = "ovalShape2";
            this.ovalShape2.SelectionColor = System.Drawing.Color.Black;
            this.ovalShape2.Size = new System.Drawing.Size(13, 13);
            // 
            // ovalShape1
            // 
            this.ovalShape1.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.ovalShape1.Location = new System.Drawing.Point(65, 27);
            this.ovalShape1.Name = "ovalShape1";
            this.ovalShape1.Size = new System.Drawing.Size(13, 13);
            // 
            // lineShape8
            // 
            this.lineShape8.Name = "lineShape8";
            this.lineShape8.X1 = 85;
            this.lineShape8.X2 = 85;
            this.lineShape8.Y1 = 22;
            this.lineShape8.Y2 = 74;
            // 
            // lineShape7
            // 
            this.lineShape7.Name = "lineShape7";
            this.lineShape7.X1 = 59;
            this.lineShape7.X2 = 85;
            this.lineShape7.Y1 = 21;
            this.lineShape7.Y2 = 21;
            // 
            // lineShape6
            // 
            this.lineShape6.Name = "lineShape6";
            this.lineShape6.X1 = 59;
            this.lineShape6.X2 = 59;
            this.lineShape6.Y1 = 22;
            this.lineShape6.Y2 = 74;
            // 
            // lineShape5
            // 
            this.lineShape5.Name = "lineShape5";
            this.lineShape5.X1 = 39;
            this.lineShape5.X2 = 59;
            this.lineShape5.Y1 = 59;
            this.lineShape5.Y2 = 59;
            // 
            // lineShape4
            // 
            this.lineShape4.Name = "lineShape4";
            this.lineShape4.X1 = 39;
            this.lineShape4.X2 = 59;
            this.lineShape4.Y1 = 35;
            this.lineShape4.Y2 = 35;
            // 
            // lineShape3
            // 
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 38;
            this.lineShape3.X2 = 38;
            this.lineShape3.Y1 = 47;
            this.lineShape3.Y2 = 59;
            // 
            // lineShape2
            // 
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 38;
            this.lineShape2.X2 = 38;
            this.lineShape2.Y1 = 34;
            this.lineShape2.Y2 = 46;
            // 
            // lineShape1
            // 
            this.lineShape1.BorderColor = System.Drawing.Color.Black;
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 15;
            this.lineShape1.X2 = 37;
            this.lineShape1.Y1 = 47;
            this.lineShape1.Y2 = 47;
            // 
            // lineShape20
            // 
            this.lineShape20.Name = "lineShape20";
            this.lineShape20.X1 = 105;
            this.lineShape20.X2 = 134;
            this.lineShape20.Y1 = 53;
            this.lineShape20.Y2 = 47;
            // 
            // lineShape19
            // 
            this.lineShape19.Name = "lineShape19";
            this.lineShape19.X1 = 105;
            this.lineShape19.X2 = 134;
            this.lineShape19.Y1 = 42;
            this.lineShape19.Y2 = 47;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "DJ";
            // 
            // UserControl1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.shapeContainer1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "UserControl1";
            this.Size = new System.Drawing.Size(221, 131);
            this.Load += new System.EventHandler(this.UserControl1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private System.Windows.Forms.Label label1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape20;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape19;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape35;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape34;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape33;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape32;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape31;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape30;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape29;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape28;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape27;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape26;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape25;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape24;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape23;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape22;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape21;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape18;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape17;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape16;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape15;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape14;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape13;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape12;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape11;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape10;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape9;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape2;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape8;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape7;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape6;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape5;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape4;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
    }
}
