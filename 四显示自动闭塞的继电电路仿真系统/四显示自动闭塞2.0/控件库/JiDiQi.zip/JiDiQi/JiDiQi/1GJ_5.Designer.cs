﻿namespace JiDiQi
{
    partial class _1GJ_5
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.line4 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.line6 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.line5 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.line3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.line2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.line1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.hou = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.zhong = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.qian = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // line4
            // 
            this.line4.BorderWidth = 2;
            this.line4.Name = "line4";
            this.line4.X1 = 18;
            this.line4.X2 = 28;
            this.line4.Y1 = 20;
            this.line4.Y2 = 20;
            // 
            // line6
            // 
            this.line6.BorderWidth = 2;
            this.line6.Name = "line6";
            this.line6.X1 = 17;
            this.line6.X2 = 25;
            this.line6.Y1 = 11;
            this.line6.Y2 = 7;
            // 
            // line5
            // 
            this.line5.BorderWidth = 2;
            this.line5.Name = "line5";
            this.line5.X1 = 4;
            this.line5.X2 = 12;
            this.line5.Y1 = 18;
            this.line5.Y2 = 14;
            // 
            // line3
            // 
            this.line3.BorderWidth = 2;
            this.line3.Name = "line3";
            this.line3.X1 = 4;
            this.line3.X2 = 12;
            this.line3.Y1 = 20;
            this.line3.Y2 = 20;
            // 
            // line2
            // 
            this.line2.BorderWidth = 2;
            this.line2.Name = "line2";
            this.line2.X1 = 5;
            this.line2.X2 = 25;
            this.line2.Y1 = 17;
            this.line2.Y2 = 6;
            // 
            // line1
            // 
            this.line1.BorderWidth = 2;
            this.line1.Name = "line1";
            this.line1.X1 = 3;
            this.line1.X2 = 28;
            this.line1.Y1 = 20;
            this.line1.Y2 = 20;
            // 
            // hou
            // 
            this.hou.BorderWidth = 2;
            this.hou.Location = new System.Drawing.Point(25, 3);
            this.hou.Name = "hou";
            this.hou.Size = new System.Drawing.Size(4, 4);
            // 
            // zhong
            // 
            this.zhong.BorderWidth = 2;
            this.zhong.Location = new System.Drawing.Point(27, 18);
            this.zhong.Name = "zhong";
            this.zhong.Size = new System.Drawing.Size(4, 5);
            // 
            // qian
            // 
            this.qian.BorderWidth = 2;
            this.qian.Location = new System.Drawing.Point(0, 17);
            this.qian.Name = "qian";
            this.qian.Size = new System.Drawing.Size(4, 4);
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.qian,
            this.zhong,
            this.hou,
            this.line1,
            this.line2,
            this.line3,
            this.line5,
            this.line6,
            this.line4});
            this.shapeContainer1.Size = new System.Drawing.Size(38, 42);
            this.shapeContainer1.TabIndex = 0;
            this.shapeContainer1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("黑体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(15, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "GJF";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(-4, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 12);
            this.label4.TabIndex = 5;
            this.label4.Text = "↑";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(-4, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(17, 12);
            this.label1.TabIndex = 6;
            this.label1.Text = "↓";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("黑体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(11, 12);
            this.label2.TabIndex = 7;
            this.label2.Text = "3";
            // 
            // _1GJ_5
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.shapeContainer1);
            this.Name = "_1GJ_5";
            this.Size = new System.Drawing.Size(38, 42);
            this.Load += new System.EventHandler(this._1GJ_5_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.VisualBasic.PowerPacks.LineShape line4;
        private Microsoft.VisualBasic.PowerPacks.LineShape line6;
        private Microsoft.VisualBasic.PowerPacks.LineShape line5;
        private Microsoft.VisualBasic.PowerPacks.LineShape line3;
        private Microsoft.VisualBasic.PowerPacks.LineShape line2;
        private Microsoft.VisualBasic.PowerPacks.LineShape line1;
        private Microsoft.VisualBasic.PowerPacks.OvalShape hou;
        private Microsoft.VisualBasic.PowerPacks.OvalShape zhong;
        private Microsoft.VisualBasic.PowerPacks.OvalShape qian;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}
