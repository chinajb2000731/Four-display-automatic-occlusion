﻿namespace JiDiQi
{
    partial class JieDian
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.line4 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.line6 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.line5 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.line3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.line2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.line1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.hou = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.zhong = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.qian = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.line4,
            this.line6,
            this.line5,
            this.line3,
            this.line2,
            this.line1,
            this.hou,
            this.zhong,
            this.qian});
            this.shapeContainer1.Size = new System.Drawing.Size(50, 33);
            this.shapeContainer1.TabIndex = 0;
            this.shapeContainer1.TabStop = false;
            // 
            // line4
            // 
            this.line4.BorderWidth = 2;
            this.line4.Name = "line4";
            this.line4.X1 = 25;
            this.line4.X2 = 37;
            this.line4.Y1 = 5;
            this.line4.Y2 = 4;
            // 
            // line6
            // 
            this.line6.BorderWidth = 2;
            this.line6.Name = "line6";
            this.line6.X1 = 29;
            this.line6.X2 = 38;
            this.line6.Y1 = 13;
            this.line6.Y2 = 7;
            // 
            // line5
            // 
            this.line5.BorderWidth = 2;
            this.line5.Name = "line5";
            this.line5.X1 = 14;
            this.line5.X2 = 25;
            this.line5.Y1 = 24;
            this.line5.Y2 = 17;
            // 
            // line3
            // 
            this.line3.BorderWidth = 2;
            this.line3.Name = "line3";
            this.line3.X1 = 8;
            this.line3.X2 = 17;
            this.line3.Y1 = 5;
            this.line3.Y2 = 5;
            // 
            // line2
            // 
            this.line2.BorderWidth = 2;
            this.line2.Name = "line2";
            this.line2.X1 = 16;
            this.line2.X2 = 41;
            this.line2.Y1 = 24;
            this.line2.Y2 = 5;
            // 
            // line1
            // 
            this.line1.BorderWidth = 2;
            this.line1.Name = "line1";
            this.line1.X1 = 6;
            this.line1.X2 = 36;
            this.line1.Y1 = 5;
            this.line1.Y2 = 5;
            // 
            // hou
            // 
            this.hou.BorderWidth = 2;
            this.hou.Location = new System.Drawing.Point(10, 24);
            this.hou.Name = "hou";
            this.hou.Size = new System.Drawing.Size(5, 5);
            // 
            // zhong
            // 
            this.zhong.BorderWidth = 2;
            this.zhong.Location = new System.Drawing.Point(36, 1);
            this.zhong.Name = "zhong";
            this.zhong.Size = new System.Drawing.Size(6, 5);
            // 
            // qian
            // 
            this.qian.BorderWidth = 2;
            this.qian.Location = new System.Drawing.Point(1, 1);
            this.qian.Name = "qian";
            this.qian.Size = new System.Drawing.Size(6, 6);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("黑体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(38, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(11, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(-2, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "↓";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("黑体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(19, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 12);
            this.label3.TabIndex = 3;
            this.label3.Text = "GJF";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(-2, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 12);
            this.label4.TabIndex = 4;
            this.label4.Text = "↑";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // JieDian
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.shapeContainer1);
            this.Name = "JieDian";
            this.Size = new System.Drawing.Size(50, 33);
            this.Tag = "1";
            this.Load += new System.EventHandler(this.JieDian_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.OvalShape qian;
        private Microsoft.VisualBasic.PowerPacks.LineShape line4;
        private Microsoft.VisualBasic.PowerPacks.LineShape line6;
        private Microsoft.VisualBasic.PowerPacks.LineShape line5;
        private Microsoft.VisualBasic.PowerPacks.LineShape line3;
        private Microsoft.VisualBasic.PowerPacks.LineShape line2;
        private Microsoft.VisualBasic.PowerPacks.LineShape line1;
        private Microsoft.VisualBasic.PowerPacks.OvalShape hou;
        private Microsoft.VisualBasic.PowerPacks.OvalShape zhong;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}
